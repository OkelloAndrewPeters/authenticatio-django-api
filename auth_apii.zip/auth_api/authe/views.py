from django.shortcuts import render, redirect
from django.http import JsonResponse
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import mixins
from .serializers import PersonSerializer
from rest_framework import permissions
from .models import Person
from django.contrib import messages
from rest_framework import generics
from rest_framework_api_key.permissions import HasAPIKey
from django.contrib.auth.models import User, auth
from rest_framework.authentication import SessionAuthentication, BasicAuthentication


class PersonView(
    mixins.ListModelMixin,
    mixins.CreateModelMixin,
    generics.GenericAPIView):

    #permission_classes = [HasAPIKey]

    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAuthenticated]

    serializer_class = PersonSerializer
    queryset = Person.objects.all()

    def get(self, request, *args, **kwargs):
        return self.list(self, request, *args, **kwargs)

    



class PersonCreateView(mixins.ListModelMixin, generics.CreateAPIView):

    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAuthenticated]
    

    #permission_classes = [IsAuthenticated]
    serializer_class = PersonSerializer
    queryset = Person.objects.all()

    def get(self, request, *args, **kwargs):
        return self.list(self, request, *args, **kwargs)



"""
class TestView(APIView):
    
    permission_classes = (IsAuthenticated, )

    def get(self, request, *args, **kwargs):
        qs = Person.objects.all()
        post = qs.first()
        #serializer = PersonSerializer(qs, many=True)
        serializer = PersonSerializer(post)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        serializer = PersonSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)
"""
