
from django.db import models
from django.contrib.auth import get_user_model


# Create your models here.


class Person(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=50)
    #owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.username





