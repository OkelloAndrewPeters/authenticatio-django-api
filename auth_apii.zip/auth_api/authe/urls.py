
from unicodedata import name
from django.urls import path, include
from . import views
from rest_framework.authtoken.views import obtain_auth_token


urlpatterns = [
    
    path('', views.PersonView.as_view()),
    path('token', obtain_auth_token, name='obtain_token'),
    path('create', views.PersonCreateView.as_view(), name='create'),
    path('api-auth/', include('rest_framework.urls')),
    
]

    